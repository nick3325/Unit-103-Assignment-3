function calc()
{
    console.log("Calculator function: ");
    //get the values from the prompt and display them on console
    let value1 = Number(prompt("First value: ")); 
    let value2 = Number(prompt("Second value: ")); 
    
    let addition;
    let subtraction;
    let division;
    let multiplication;

    addition = value1 + value2;
    subtraction = value1 - value2;
    division = value1 / value2;
    multiplication = value1 * value2;

    document.getElementById("results").innerHTML=`
    <p class="result"> ${value1} + ${value2} = ${addition}</p>
    <p class="result"> ${value1} - ${value2} = ${subtraction}</p>
    <p class="result"> ${value1} / ${value2} = ${division}</p>
    <p class="result"> ${value1} * ${value2} = ${multiplication}</p>
    `;
}